<?php
$servername= 'localhost' ; 
$username= 'root' ;
$password= '' ; 
$dbname = "bus"; 
$conn=mysqli_connect($servername,$username,$password, "$dbname" );
if (!$conn){
die ( 'Could not Connect My Sql:' .mysql_error());
}

if ( isset( $_POST [ 'sub' ]))
{
	$username = $_POST [ 'username' ];
	$email = $_POST [ 'email' ];
	$message = $_POST ['message'];
	
	
	
	if(empty($username) || empty($email) || empty($message)) {
		echo 'all fields must be filled';
	}else{
$sql = "INSERT INTO contact (username,email,message)
VALUES ('$username','$email','$message')" ;
if (mysqli_query($conn, $sql)) {
echo "message sent successfully !" ;
} else {
echo "Error: " . $sql . "
" . mysqli_error($conn);
}
mysqli_close($conn);
}
	}
?>



<!DOCTYPE html>
<html lang="">
<head>
				<meta charset="utf-8">
				<meta name="viewport" content="width=device-width, initial-scale=1.0">
				<title>contact</title>
	<style>
	
		#div-one{
			background-color: cadetblue;
			margin-left: 340px;
			margin-top: 10px;
			width: 800px;
			height: 550px;
			border-radius: 16px;
			align-content: center;
		}
		form{

		margin: 50px;
		
		}
		body{
     		text-align: center;
			text-decoration-color: aqua;
			font-size: 20px;
			font-family:cursive;
			align-content: center;
		}
		#sub{
			background-color: aqua;
			height: 35px;
			width: 70px;
			border-radius: 15px;
		}
		h3{
			color: cadetblue;
			font-size: 30px;
		}
		
#div0{
            height: 50px;
            width: 100%;
            background-color: blue;
            position: fixed;
            margin-bottom: 100px;
            
        } 
		 *, html, body{
    margin: 0;
    padding: 0;
}


ul
{
    list-style: none;
   
}
ul li{
display: inline-block;
    float: right;
    padding-top: 15px;
    
}
        nav ul li a{
    padding-right: 50px;
    font-weight: bold;
    color: white;
     text-decoration: none;
    transition: 0.8s ease-in;
}
        a:hover{
            color: aqua;
            font-size: 25px;
        }
		
		.pic{
			height: 30px;
			width: 50px;
			margin-right: 30px;
		}
		
	</style>
</head>

<body>
  
    <div id="div0">
     
      <nav>
      <h1 style="float:left; color:white; padding-top:15px; padding-left:15px">welcome to BLAB travel and tour</h1>
      <ul>
      <li></li> 
       <li><img src ="images/download%20(1).jpg" class="pic"></li>
       <li><img src ="images/unnamed.jpg" class="pic"></li>
       <li><img src ="images/images%20(15).jpg" class="pic"></li>
       <li><img src ="images/images%20(14).jpg" class="pic"></li>
       <li><a href="https://covid19.who.int/?gclid=EAIaIQobChMIg5D3s5fL6wIV1prVCh0T8AcCEAAYASAAEgLHOvD_BwE">covid-19 news</a></li>
       </ul>
       </nav>
     </div>
     
     	
     
  
  
  <br><br><br><br>
   <h3>we are glad to hear from you, thank you for contacting us!!!!</h3>
    <div id="div-one">
	<form action="" method="post">
		username:
		<br><br><input type="text" name="username"><br><br><br>
		email:
		<br><br><input type="text" name="email"><br><br><br>
		message:
		<br><br><textarea name="message" id="" cols="30" rows="10"></textarea><br>
		<input type="submit" name="sub" id="sub">
		
	</form>
	</div>			
</body>
</html>
