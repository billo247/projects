<?php
$price = "";
$message = "";
$randomNumber = "";
$seats = "";
$route = "";
$servername= 'localhost' ; 
$username= 'root' ;
$password= '' ; 
$dbname = "busses"; 
$conn=mysqli_connect($servername,$username,$password, "$dbname" );
if (!$conn){
die ( 'Could not Connect My Sql:' .mysql_error());
}

if ( isset( $_POST [ 'book' ]))
{
	$route = $_POST [ 'rad' ];
	$seats = $_POST [ 'seats' ];
	$date = $_POST ['date' ];
	
	
	
	if(empty($route) || empty($seats) || empty($date)) {
		echo 'all fields must be filled';
	}else{
$sql = "INSERT INTO bookings (route,seats,date)
VALUES ('$route','$seats','$date')" ;
if (mysqli_query($conn, $sql)) {
$message = "booking done successfully !" ;
	//echo "thanks";
	
	$randomNumber = rand();
	//print_r($randomNumber);
	print_r("\n");
	$randomNumber = rand(15,30);
	//echo $randomNumber;
	//print_r($randomNumber);
	if ($route == "Accra-to-kumasi"){
		$price=$seats * 50;	
	}elseif($route == "Accra-to-capecoast"){
		echo "<br>" .$seats * 70;
	}elseif($route == "Accra-to-Ho"){
		echo "<br>" .$seats * 60;
	}elseif($route == "Accra-to-Tamale"){
		echo "<br>" .$seats * 80;
	}elseif($route == "Tamale-to-Accra"){
		echo "<br>" .$seats * 120;
	}elseif($route == "Tamale-to-kumasi"){
		echo "<br>" .$seats * 120;
	}elseif($route == "Tamale-to-Capecoast"){
		echo "<br>" .$seats * 110;
	}elseif($route == "Tamale-to-Ho"){
		echo "<br>" .$seats * 100;
	}elseif($route == "Kumasi-to-Accra"){
		echo "<br>" .$seats * 50;
	}elseif($route == "Kumasi-to-Tamale"){
		echo "<br>" .$seats * 120;
	}elseif($route == "Kumasi-to-Capecoast"){
		echo "<br>" .$seats * 30;
	}elseif($route == "Kumasi-to-Ho"){
		echo "<br>" .$seats * 40;
	
	}
	
} else {
echo "Error: " . $sql . "
" . mysqli_error($conn);
}
mysqli_close($conn);
}
	}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>booking</title>
    
    <style type="text/css">
        
        #div1{
            border-right: 2px green solid;
            background-color:cadetblue;
            height: 650px;
            width: 50%;
            text-decoration-color: darkmagenta;
            float: left;
        }
        #div2{
            
            background-color:darkgrey;
            height: 650px;
            width: 48%;
            float: left;
        }
        #div3{
            padding-left: 30px;
        }
		.formdiv{

		height:250px;
		width: 300px;
		float: left;
			border: 2px solid yellow; 
		}
		
	#books{		 
    height: 60px;
    width: 140px;
    font-size: 25px;
    text-transform: uppercase;
    border: 0;
    color: white;
    background: lightgreen;
    cursor: pointer;  
    }
		#cancel{
			height: 60px;
    width: 140px;
    font-size: 15px bold;
    text-transform: uppercase;
    border: 0;
    color: white;
    background: red;
    cursor: pointer;
		}
		
		#ticket{

			height: 200px;
			width: 400px;
			background-color: white;
			float: right;
			border: 2px yellow solid;
		}
    </style>
    
</head>
<body>
   <h1 style="color: darkblue; text-align: center">BOOKING PAGE</h1>
    <div id="div1">
    
    <h3 style="color: white; font-display: fallback">CHECKOUT OUR ROUTES AND FARES FROM THE DROP DOWN</h3>
     <h1>select root from Accra</h1>
     <p>
      
        <select>
            <option>Accra-to-kumasi (ghs 50.00)</option>
            <option>Accra-to-capecoast (ghs 70.00)</option>
            <option>Accra-to-ho (ghs 60.00)</option>
            <option>Accra-to-Tamale (ghs 80.00)</option>
        </select>
        </p>
        
                <h1>select root from Tamale</h1>

     <p>
       
        <select>
            <option>Tamale-to-Accra (ghs 120.00)</option>
            <option>Tamale-to-Kumasi (ghs 120.00)</option>
            <option>Tamale-to-Capecoast (ghs 110.00)</option>
            <option>Tamale-to-Ho (ghs 100.00)</option>
        </select>
        </p>
        
                <h1>select root from kumasi </h1>

     <p>
        <select>
            <option>Kumasi-To-Accra (ghs 50.00)</option>
            <option>Kumasi-To-tamale (ghs 120.00)</option>
            <option>Kumasi-To-Capecoast (ghs 30.00)</option>
            <option>Kumasi-To-Ho (ghs 40.00)</option>
        </select>
        </p>
     
    
   </div> 
   
   
   <div id="div2">
     <div id="div3">
      <h2>book now!!!! select route</h2> 
       <form action="" method="post">
       <div class="formdiv" name="rad">
       <input type="radio" name="rad" value="Accra-to-kumasi">Accra-to-kumasi<br>
       <br><input type="radio" name="rad" value="Accra-to-capecoast">Accra-to-capecoast<br> 
       <br><input type="radio" name="rad" value="Accra-to-Ho">Accra-to-Ho<br> 
       <br><input type="radio" name="rad" value="Accra-to-Tamale">Accra-to-Tamale<br>
       <br><input type="radio" name="rad" value="Tamale-to-Accra">Tamale-to-Accra<br> 
       <br><input type="radio" name="rad" value="Tamale-to-Kumasi">Tamale-to-Kumasi<br>
       </div>
       <div class="formdiv">
       
       <input type="radio" name="rad" value="Tamale-to-Capecoast">Tamale-to-Capecoast<br> 
       <br><input type="radio" name="rad" value="Tamale-to-Ho">Tamale-to-Ho<br> 
       <br><input type="radio" name="rad" value="Kumasi-to-Accra">Kumasi-To-Accra<br> 
       <br><input type="radio" name="rad" value="Kumasi-to-Tamale">Kumasi-To-tamale<br> 
       <br><input type="radio" name="rad" value="Kumasi-to-Capecoast">Kumasi-To-Capecoast<br> 
       <br><input type="radio" name="rad" value="Kumasi-to-Ho">Kumasi-To-Ho<br> 
       
       </div> 
       <hr>
       <h3>how many seats are u booking? select seats</h3>
       <select name="seats">
           
            <option>1</option>
            <option>2</option>
            <option>4</option>
            <option>5</option>
            <option>6</option>
            <option>7</option>
            <option>8</option>
            <option>9</option>
            <option>10</option>
            <option>11</option>
            <option>12</option>
            <option>13</option>
            <option>14</option>
            <option>15</option>
            <option>rent the whole bus</option>
        
        </select>
      <div id="ticket">
      	<?php
		  echo "<<<<<<<<'...BOOKING INFO...'>>>>>>>><br><br>";
		  echo $message."<br><br>";
		  echo "booked, your fare is>>>>>>>> GH¢". $price."<br><br>";
		  echo "your booking ID is.....". $randomNumber."<br><br>";
		  echo "number of seats booked: ". $seats."<br><br>";
		  echo "route :". $route; 
		?>  
      </div>
        <p>enter travel date</p>
        <input type="date" name="date"><br><br><br>
       <input type="submit" name="book" id="books" value="book"><br>
       
       
      <br> <input type="submit" name="cancel" id="cancel" value="cancel booking">
 
      </form>
       
      </div> 
     
   </div>
 
   
</body>
</html>