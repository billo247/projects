<?php
$price = "";
$randNumber = "";
$regnum = "";
$message = "";
$randomNumber = "";
$seats = "";
$route = "";
$servername= 'localhost' ; 
$username= 'root' ;
$password= '' ; 
$dbname = "bus"; 
$conn=mysqli_connect($servername,$username,$password, "$dbname" );
if (!$conn){
die ( 'Could not Connect My Sql:' .mysql_error());
}

if ( isset( $_POST [ 'book' ]))
{
	$route = mysqli_real_escape_string($conn,$_POST [ 'rad' ]);
	$seats = $_POST [ 'seats' ];
	$date = $_POST ['date' ];
	//$randomNumber = $_POST['randomNumber'];
	
	

	//echo "thanks";
	
	$randomNumber = rand();
	//print_r($randomNumber);
	print_r("\n");
	$randomNumber = rand(15,30);
	//echo $randomNumber;
	//print_r($randomNumber);
	if ($route == "Accra-to-kumasi"){
		$price=$seats * 50;	
	}elseif($route == "Accra-to-capecoast"){
		$price=$seats * 70;
	}elseif($route == "Accra-to-Ho"){
		$price=$seats * 60;
	}elseif($route == "Accra-to-Tamale"){
		$price=$seats * 80;
	}elseif($route == "Tamale-to-Accra"){
		$price=$seats * 120;
	}elseif($route == "Tamale-to-kumasi"){
		$price=$seats * 120;
	}elseif($route == "Tamale-to-Capecoast"){
		$price=$seats * 110;
	}elseif($route == "Tamale-to-Ho"){
		$price=$seats * 100;
	}elseif($route == "Kumasi-to-Accra"){
		$price=$seats * 50;
	}elseif($route == "Kumasi-to-Tamale"){
		$price=$seats * 120;
	}elseif($route == "Kumasi-to-Capecoast"){
		$price=$seats * 30;
	}elseif($route == "Kumasi-to-Ho"){
		$price=$seats * 40;
	};
	
		$regnum = rand();
	print_r("\n");
	$regnum = "GN". rand(2504,4895);
		
	if(empty($route) || empty($seats) || empty($date)) {
		echo 'all fields must be filled';
		$message = "booking failed";
		
	}else{
$sql = "INSERT INTO bookings (route,seats,date,random)
VALUES ('$route','$seats','$date',$randomNumber)" ;
if (mysqli_query($conn, $sql)) {
$message = "booking done successfully !" ;
} else {
/*echo "Error: " . $sql . "
" . mysqli_error($conn);
*/
}
mysqli_close($conn);
}
	}

	if ( isset( $_POST [ 'cancel' ]))
{
	//$randomNumber = $_POST['randomNumber'];
	
$sql = "DELETE FROM bookings WHERE random = '$randomNumber'";
if (mysqli_query($conn, $sql)) {
  echo "cancellation successful !" ;
} else {
echo "Error: " . $sql . "
" . mysqli_error($conn);
}
mysqli_close($conn);
}


if ( isset( $_POST [ 'check' ]))
{
	
	$yourroute = $_POST [ 'ch-av' ];
	if (empty($yourroute)){
		$message = "enter";
	}else{
		
    	$randNumber = rand();
	//print_r($randomNumber);
	print_r("\n");
	$randNumber = rand(7,19);
	
	$regnum = rand();
	print_r("\n");
	$regnum = "GN". rand(2504,4895);
}
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>booking</title>
    
    <style type="text/css">
        
        #div1{
            border-right: 2px green solid;
            background-color:cadetblue;
            height: 700px;
            width: 50%;
            text-decoration-color: darkmagenta;
            float: left;
        }
        #div2{
            
            background-color:darkgrey;
            height: 700px;
            width: 49%;
            float: left;
        }
		
        #div3{
            padding-left: 30px;
        }
		.formdiv{
		height:250px;
		width: 300px;
		float: left;
		border: 2px solid yellow; 
		}
		
		.form-div{
		height:250px;
		width: 320px;
		float: left;
		border: 2px solid yellow; 
		}
		
	#books{		 
    height: 40px;
    width: 140px;
    font-size: 25px;
    text-transform: uppercase;
    border: 0;
    color: white;
    background: lightgreen;
    cursor: pointer;  
    }
		
	#check{		 
    height: 40px;
    width: 160px;
    font-size: 15px;
    text-transform: uppercase;
    border: 0;
    color: white;
    background: lightgreen;
    cursor: pointer;
	margin-left: 29px;
		margin-top: 12px;
    }	
		#cancel{
			height: 40px;
    width: 140px;
    font-size: 15px bold;
    text-transform: uppercase;
    border: 0;
    color: white;
    background: red;
    cursor: pointer;
		}
		
		#ticket{

			height: 240px;
			width: 400px;
			background-color: white;
			float: right;
			border: 2px yellow solid;
		}
		#check-avail{

			height: 140px;
			width: 400px;
			background-color: white;
			color: darkkhaki;
			font-size: 20px;
			float: right;
			border: 2px yellow solid;
		}
		h2{
			color: yellow;
		}
		
		#div0{
            height: 50px;
            width: 100%;
            background-color: blue;
            position: fixed;
            margin-bottom: 100px;
            
        } 
		 *, html, body{
    margin: 0;
    padding: 0;
}


ul
{
    list-style: none;
   
}
ul li{
display: inline-block;
    float: right;
    padding-top: 15px;
    
}
        nav ul li a{
    padding-right: 50px;
    font-weight: bold;
    color: white;
     text-decoration: none;
    transition: 0.8s ease-in;
}
        a:hover{
            color: aqua;
            font-size: 25px;
        }
		
		.pic{
			height: 30px;
			width: 50px;
			margin-right: 30px;
		}
		
		
    </style>
    
</head>
<body>
  
  
    <div id="div0">
     
      <nav>
      <h1 style="float:left; color:white; padding-top:15px; padding-left:15px">welcome to BLAB travel and tour</h1>
      <ul>
      <li></li> 
       <li><img src ="images/download%20(1).jpg" class="pic"></li>
       <li><img src ="images/unnamed.jpg" class="pic"></li>
       <li><img src ="images/images%20(15).jpg" class="pic"></li>
       <li><img src ="images/images%20(14).jpg" class="pic"></li>
       <li><a href="https://covid19.who.int/?gclid=EAIaIQobChMIg5D3s5fL6wIV1prVCh0T8AcCEAAYASAAEgLHOvD_BwE">covid-19 news</a></li>
       </ul>
       </nav>
     </div>
     
     	
     
  
  
  <br><br><br><br>
   <h1 style="color: darkblue; text-align: center">BOOKING PAGE</h1>
    <div id="div1">
    
    <h3 style="color: white; font-display: fallback">CHECKOUT OUR ROUTES AND FARES FROM THE DROP DOWN</h3>
    
    
   <div>    
   <form action="" method="post">
       <div class="form-div">
       <input type="radio" name="ch-av" value="Accra-to-kumasi" checked="checked">Accra-to-kumasi (ghs50.00)<br>
       <br><input type="radio" name="ch-av" value="Accra-to-capecoast">Accra-to-capecoast (ghs70.00)<br> 
       <br><input type="radio" name="ch-av" value="Accra-to-Ho">Accra-to-Ho (ghs60.00)<br> 
       <br><input type="radio" name="ch-av" value="Accra-to-Tamale">Accra-to-Tamale (ghs80.00)<br>
       <br><input type="radio" name="ch-av" value="Tamale-to-Accra">Tamale-to-Accra (ghs120.00)<br> 
       <br><input type="radio" name="ch-av" value="Tamale-to-Kumasi">Tamale-to-Kumasi (ghs120.00)<br>
       </div>
       <div class="form-div">
       
       <input type="radio" name="ch-av" value="Tamale-to-Capecoast">Tamale-to-Capecoast (ghs110.00)<br> 
       <br><input type="radio" name="ch-av" value="Tamale-to-Ho">Tamale-to-Ho (ghs100.00)<br> 
       <br><input type="radio" name="ch-av" value="Kumasi-to-Accra">Kumasi-To-Accra (ghs50.00)<br> 
       <br><input type="radio" name="ch-av" value="Kumasi-to-Tamale">Kumasi-To-tamale (ghs120.00)<br> 
       <br><input type="radio" name="ch-av" value="Kumasi-to-Capecoast">Kumasi-To-Capecoast (ghs30.00)<br> 
       <br><input type="radio" name="ch-av" value="Kumasi-to-Ho">Kumasi-To-Ho (ghs40.00)<br> 
       
       </div> 
       <input type="submit" name="check" id="check" value="check availabity"><br>
		</form>
     </div>
         <div id="check-avail">
       	<?php
       	   	 echo "number of available seats.....". $randNumber."<br><br>";
		   	 echo "vehicle registration number...". $regnum."<br><br>";
			 
		   
       	?>
       </div>
     
  <br><h2>pay with mobile money on : 0543288247 use your booking Id as reference</h2><br>
   <h2>you can also pay cash at the BLAB bus terminal</h2>
   <h2>for more information on payment contact : 0273862591 via call or whatsapp</h2>

   </div> 
   
   
   <div id="div2">
     <div id="div3">
      <h2>book now!!!! select route</h2> 
       <form action="" method="post">
       <div class="formdiv" name="rad">
       <input type="radio" name="rad" value="Accra-to-kumasi" checked ="checked">Accra-to-kumasi (ghs50.00)<br>
       <br><input type="radio" name="rad" value="Accra-to-capecoast">Accra-to-capecoast (ghs70.00)<br> 
       <br><input type="radio" name="rad" value="Accra-to-Ho">Accra-to-Ho (ghs60.00)<br> 
       <br><input type="radio" name="rad" value="Accra-to-Tamale">Accra-to-Tamale (ghs80.00)<br>
       <br><input type="radio" name="rad" value="Tamale-to-Accra">Tamale-to-Accra (ghs120.00)<br> 
       <br><input type="radio" name="rad" value="Tamale-to-Kumasi">Tamale-to-Kumasi (ghs120.00)<br>
       </div>
       <div class="formdiv">
       
       <input type="radio" name="rad" value="Tamale-to-Capecoast">Tamale-to-Capecoast (ghs110.00)<br> 
       <br><input type="radio" name="rad" value="Tamale-to-Ho">Tamale-to-Ho (ghs100.00<br> 
       <br><input type="radio" name="rad" value="Kumasi-to-Accra">Kumasi-To-Accra (ghs50.00)<br> 
       <br><input type="radio" name="rad" value="Kumasi-to-Tamale">Kumasi-To-tamale (ghs120.00)<br> 
       <br><input type="radio" name="rad" value="Kumasi-to-Capecoast">Kumasi-To-Capecoast (ghs30.00)<br> 
       <br><input type="radio" name="rad" value="Kumasi-to-Ho">Kumasi-To-Ho (ghs40.00)<br> 
       
       </div> 
       <hr>
       <h3>how many seats are u booking? select seats</h3>
       <select name="seats">
           
            <option>1</option>
            <option>2</option>
            <option>4</option>
            <option>5</option>
            <option>6</option>
            <option>7</option>
            <option>8</option>
            <option>9</option>
            <option>10</option>
            <option>11</option>
            <option>12</option>
            <option>13</option>
            <option>14</option>
            <option>15</option>
            
        
        </select>
      <div id="ticket">
      	<?php
		  echo "...........BOOKING INFO.............<br><br>";
		  echo "booking status...". $message."<br><br>";
		  echo "your fare is......... GH¢". $price."<br><br>";
		  echo "your booking ID is.....". $randomNumber."<br><br>";
		  echo "number of seats booked :.... ". $seats."<br><br>";
		  echo "route :.....". $route. "<br>"; 
		  echo "vehicle registration number ..." .$regnum;
		?>  
      </div>
       
   
        <p>enter travel date</p>
        <input type="date" name="date"><br><br><br>
       <input type="submit" name="book" id="books" value="book"><br>
       
       <form action="" method="post">
       enter your booking id to cancel booking:
       <input type="text" name="cancel-booking"><br>
      <br> <input type="submit" name="cancel" id="cancel" value="cancel booking">
 		</form>
      </form>
       
      </div> 
     
   </div>
 
   
</body>
</html>