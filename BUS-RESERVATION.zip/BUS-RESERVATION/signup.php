<?php
session_start();
$servername= 'localhost' ; 
$username= 'root' ;
$password= '' ; 
$dbname = "bus"; 
$conn=mysqli_connect($servername,$username,$password, "$dbname" );
if (!$conn){
die ( 'Could not Connect My Sql:' .mysql_error());
}

if ( isset( $_POST [ 'save' ]))
{
	$fname = $_POST [ 'fname' ];
	$lname = $_POST [ 'lname' ];
	$email = $_POST ['email' ];
	$telephone = $_POST ['telephone' ];
	$gender = $_POST ['gender'];
	$password = $_POST ['password' ];
	$username = $_POST ['username' ];
	$city = $_POST ['city' ];
	$workplace = $_POST ['workplace' ];
	
	$unique= mysqli_query($conn,"SELECT * FROM customers where username = '$username'");
	
	if(mysqli_num_rows($unique)>0){

		echo "username is already taken, please choose another username.";
	}elseif(empty($fname) || empty($lname) || empty($email) || empty($telephone) || empty($gender) ||empty($password) || empty($username) || empty($city) ||empty($workplace)){
		echo 'all fields must be filled before you can create an account.';
	}else{
$sql = "INSERT INTO customers (fname,lname,email,telephone,gender,password,username,city,workplace)
VALUES ('$fname','$lname','$email','$telephone','$gender','$password','$username','$city','$workplace')" ;
if (mysqli_query($conn, $sql)) {
	$_SESSION['username'] = $username;
	$_SESSION['success'] = "you are now logged in";
	header('location: first-page.php');
	if (isset($_GET['logout'])){
		session_destroy();
		unset($_SESSION['username']);
		header('buslog-in.php');
	}
echo "Account created successfully !" ;
} else {
echo "Error: " . $sql . "
" . mysqli_error($conn);
}
mysqli_close($conn);
}
	}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>signup</title>
</head>
<style type="text/css">
    #f1{
        background-color: gray;
        border: 4px solid red;
        width: 50%;;
        height: 580px;
        float: left;
        
    }
    #f2{
    height: 60px;
    width: 140px;
    font-size: 20;
    text-transform: uppercase;
    border: 0;
    color: white;
    background: yellow;
    cursor: pointer;  
    }
    #form1{
        padding-left: 100px;
        font-size: 20px;
        float: left;
    }
    #div2{
        float:right;
        height: 500px;
        width: 48%;
    }
    #div1{
        float: left;
    }
    .f2{
     height: 60px;
    width: 140px;
    font-size: 20;
    text-transform: uppercase;
    border: 0;
    color: white;
    background: green;
    cursor: pointer;
    padding-left: 30px; 
    float:left;    
    }
    #div0{
            height: 50px;
            width: 100%;
            background-color: blue;
            position: fixed;
            margin-bottom: 100px;
            
        } 
		 *, html, body{
    margin: 0;
    padding: 0;
}


ul
{
    list-style: none;
   
}
ul li{
display: inline-block;
    float: right;
    padding-top: 15px;
    
}
        nav ul li a{
    padding-right: 50px;
    font-weight: bold;
    color: white;
     text-decoration: none;
    transition: 0.8s ease-in;
}
        a:hover{
            color: aqua;
            font-size: 25px;
        }
		
		.pic{
			height: 30px;
			width: 50px;
			margin-right: 30px;
		}
</style>
<body>
        <div id="div0">
     
      <nav>
      <h1 style="float:left; color:white; padding-top:15px; padding-left:15px">welcome to BLAB travel and tour</h1>
      <ul>
      <li></li> 
       <li><img src ="images/download%20(1).jpg" class="pic"></li>
       <li><img src ="images/unnamed.jpg" class="pic"></li>
       <li><img src ="images/images%20(15).jpg" class="pic"></li>
       <li><img src ="images/images%20(14).jpg" class="pic"></li>
       <li><a href="https://covid19.who.int/?gclid=EAIaIQobChMIg5D3s5fL6wIV1prVCh0T8AcCEAAYASAAEgLHOvD_BwE">covid-19 news</a></li>
       </ul>
       </nav>
     </div>
     
     	
     
  
  
  <br><br><br><br>
        
        
         <h1 style="color: red; text-align: center">WELCOME TO THE REGISTRATION PAGE</h1>
          
          
           <div id="f1">
           
            <form action="" method="post" id="form1">
                <h3>CREATE ACCOUNT</h3>
                 <br>first name &nbsp;&nbsp;&nbsp;<input type="text" name="fname" placeholder="enter your first name"><br> 
                 <br>last name &nbsp;&nbsp; &nbsp;<input type="text" name="lname" placeholder="enter your last name"><br> 
                 <br>email &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <input type="text" name="email" placeholder="enter your email"><br> 
                 <br>telephone&nbsp; &nbsp;&nbsp;<input type="text" name="telephone" placeholder="enter your telephone"><br>     
                 <br>gender &nbsp; &nbsp; &nbsp;&nbsp;   <input type="text" name="gender" placeholder="enter your gerder"><br> 
                 <br>password &nbsp; &nbsp;<input type="text" name="password" placeholder="enter a strong password"><br> 
                 <br>username &nbsp;&nbsp; <input type="text" name="username" placeholder="enter your username"><br> 
                 <br>city &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  <input type="text" name="city" placeholder="enter your city/town"><br> 
                 <br>workplace &nbsp;<input type="text" name="workplace" placeholder="enter your company name"><br> 
              
                 <br><input type="submit" value="submit" name="save" id="f2">
           
        
        </form>
        </div>
        
        
        <div id="div2">
          <img src="images/images.png" alt="">  
        <img src="images/download%20(4).jpg" alt="">  
        <img src="images/download%20(6).jpg" alt="">  
        <h2 style="font-style: italic">the luxury of traveling</h2>  
        </div>
        
        
</body>
</html>