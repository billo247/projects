<?php
	$con = mysqli_connect("localhost","root","","bus");
if(mysqli_connect_errno()){
	echo 'failed to connect to database'.mysqli_connect_error();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>php print</title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="print.css" media="print">
	
	<style type="text/css">
	
	  #div0{
            height: 100px;
            width: 100%;
            background-color: blue;
            position: fixed;
            margin-bottom: 100px;
            
        } 
		 *, html, body{
    margin: 0;
    padding: 0;
}


ul
{
    list-style: none;
   
}
ul li{
display: inline-block;
    float: right;
    padding-top: 15px;
    
}
        nav ul li a{
    padding-right: 50px;
    font-weight: bold;
    color: white;
     text-decoration: none;
    transition: 0.8s ease-in;
}
        a:hover{
            color: aqua;
            font-size: 25px;
        }
		
		.pic{
			height: 30px;
			width: 50px;
			margin-right: 30px;
		}
		
	</style>
</head>
<body>


    <div id="div0">
     
      <nav>
      <h1 style="float:left; color:white; padding-top:0px; padding-left:15px">user comments</h1>
      <ul>
      
       <li><img src ="images/download%20(1).jpg" class="pic"></li>
       <li><img src ="images/unnamed.jpg" class="pic"></li>
       <li><img src ="images/images%20(15).jpg" class="pic"></li>
       <li><img src ="images/images%20(14).jpg" class="pic"></li>
       <li><a href="https://covid19.who.int/?gclid=EAIaIQobChMIg5D3s5fL6wIV1prVCh0T8AcCEAAYASAAEgLHOvD_BwE">covid-19 news</a></li>
       </ul>
       </nav>
     </div>
     
     	
     
  
  
  <br><br><br><br>
	<div class="container">
		
		<div class="row">
			
			<div class="col-md-12">
				<h2>user data</h2>
				<table class="table table-bordered">
					
					<thead>
						
						<tr>
							
							<th>S. no</th>
							<th>id</th>
							<th>username</th>
							<th>email</th>
							<th>message</th>
							
						</tr>
						
					</thead>
					<tbody>
						<?php
						$sn = 1;
						$user_query = 'SELECT * FROM contact';
						$user_result = mysqli_query($con,$user_query);
						while($user_data = mysqli_fetch_assoc($user_result)){
						?>
						
						<tr>
							<td><?php echo $sn ?></td>
							<td><?php echo $user_data['id'] ?></td>
							<td><?php echo $user_data ['username'] ?></td>
							<td><?php echo $user_data ['email'] ?></td>
							<td><?php echo $user_data ['message'] ?></td>
							
							
							
							
						</tr>
						<?php
							
						$sn++;
						}
						?>
						
					</tbody>
				</table>
				<div class="text-center">
					<button onclick="window.print();" class="btn btn-primary" id="print-btn">print</button>
					
				</div>
			</div>
			
		</div>
		
	</div>
</body>
</html>






