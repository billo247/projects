<?php
session_start();
$mess = "";
$con = mysqli_connect("localhost","root","","bus");

if(isset($_POST['log'])){
  $username = mysqli_real_escape_string($con,$_POST['username']);
  $password = mysqli_real_escape_string($con,$_POST['password']);
	
    if($username !="" && $password !=""){
		$sql = "SELECT id FROM admin WHERE username='$username' and password='$password'";
		$result = mysqli_query($con,$sql);
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		
		$count = mysqli_num_rows($result);
		if($count==1){
			$_SESSION['username']= $username;
				header("location: admin.php");
			exit();
		echo 'welcome';
		}
	}else{
		$mess = "wrong username or password";
	}

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>log-in</title>
    <link rel="stylesheet" href="login-styles.css">
</head>
<body text="blue">
  
   <div id="div1">
  
    <form action="" method="POST">
        
    <br>Username &nbsp;<input type="text" name="username" class="inp"><br>
    <br>Password &nbsp; <input type="text" name="password" class="inp"><br>
     <br><a href="signup.php">sign up</a>    
     <input id="but" type="submit" name="log" value="log in">   
      
    </form>
    <?php
	   echo $mess;
	  ?> 
    </div>
</body>
</html>