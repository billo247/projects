<?php
$msg = "";
$servername= 'localhost' ; 
$username= 'root' ;
$password= '' ; 
$dbname = "bus"; 
$conn=mysqli_connect($servername,$username,$password, "$dbname" );
if (!$conn){
die ( 'Could not Connect My Sql:' .mysql_error());
}
	if ( isset( $_POST [ 'delete' ]))
{
	$username = $_POST [ 'username' ];
	
	if(empty($username) ) {
	$msg = 'enter a username';
	}else{
$sql = "DELETE FROM customers WHERE username = '$username'";
if (mysqli_query($conn, $sql)) {
  $msg = "deletion successful !" ;
} else {
echo "Error: " . $sql . "
" . mysqli_error($conn);
}
mysqli_close($conn);
}
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>firstpage</title>
    
    
    
    <style type="text/css">
     #div1{
            border-right: 4px blue solid;
            background-color: grey;
            height: 650px;
            width: 50%;
            text-decoration-color: darkred;
            float: left;
            padding-top: 100px;
		    
        }
    
    #div2{
        float:right;
        height: 500px;
        width: 48%;
        padding-top: 100px;
    }
     #div0{
            height: 50px;
            width: 100%;
            background-color: blue;
            position: fixed;
            margin: 0px;
            
        }
     #inner-div-one{
			margin-left: 40px;
		}
	#footer{
            height: 50px;
            width: 100%;
            background-color: grey;
            position: relative;
            margin: 0px;
            
        } 

		*, html, body{
		margin: 0;
		padding: 0;
	}


	ul
	{
		list-style: none;

	}
	ul li{
	    display: inline-block;
		float: right;
		padding-top: 15px;

	}
			nav ul li a{
		padding-right: 50px;
		font-weight: bold;
		color: white;
		text-decoration: none;
		transition: 0.8s ease-in;
	}
            a:hover{
            color: aqua;
            font-size: 25px;      
        } 
        #h33{
            float: right;
            padding-top: 15px;
        }
		.clear{

		clear: both;
		}
			#delete{		 
    height: 40px;
    width: 100px;
    font-size: 20px;
    text-transform: uppercase;
    border: 0;
    color: white;
    background: red;
    cursor: pointer;  
    }
		
		  #f2{
    height: 30px;
    width: 80px;
    font-size: 20;
    text-transform: uppercase;
    border: 0;
    color: red;
    background: yellow;
    cursor: pointer; 
		}
		p{
			font-size: 25px;
			color: aqua;
		}
    </style>
    
    
</head>
<body>
     <div id="div0">
     
      <nav>
      <h1 style="float:left; color:white; padding-top:15px; padding-left:15px">welcome to BLAB travel and tour - admin page</h1>
      <ul>
      <li></li> 
       <li><a href="contact-list.php">view coments</a></li>
       <li><a href="bookings-list.php">view bookings</a></li>
       <li><a href="subscriber-list.php">view subscriber list</a></li>
       </ul>
       </nav>
     </div>
     
     
     
     
      <div id="div1">
     <div id="inner-div-one">
    <h2 style="color: white; font-display: fallback">WELCOME</h2>
           <hr>
          <br><br>
          <div>
          	<form action="" method="post">
		<h2>Delete a subscriber</h2><br><br>
		<h2>enter username to delete</h2>
		<input type="text" name="username" style="height: 40px; width: 180px">
		<button type="submit" name="delete" id="delete">delete</button>
		
	</form>
         <?php
		   echo $msg;	  
		?>	  
          </div>
          <br><br><br>
          <P>QUICK NOTES</P>
          <P>you can view and print the subscriber list, the bookings made and customer comments </P>
          
     
    </div>
   </div> 
   
        
        
        <div id="div2">
          <img src="images/images.png" alt="">  
        <img src="images/download%20(4).jpg" alt="">  
        <img src="images/download%20(6).jpg" alt="">  
          <img src="images/images.png" alt="">  
        <img src="images/download%20(8).jpg" alt="">  
        <img src="images/download%20(9).jpg" alt="">
        <h2 style="font-style: italic">the luxury of traveling</h2> 
         
        </div>
        <div class="clear"></div>
        
     <div id="footer">
      <nav>
      <h1 style="float:left; color:white; padding-top:15px; padding-left:15px">welcome to BLAB travel and tour</h1>
      <ul>
      <li></li> 
       <li><a href="twitter.com/eddiebrempong"><img src="" alt=""></a></li>
       <li><a href="">@eddiebrempong</a></li>
       <li><a href="signup.php">Contact Us</a></li>
       </ul>
       </nav>
      
     </div>
</body>
</html>
