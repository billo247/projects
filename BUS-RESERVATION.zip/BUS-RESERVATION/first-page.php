<?php

session_start();

?>	
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>firstpage</title>
    <style type="text/css">
     #div1{
            border-right: 4px blue solid;
            background-color: grey;
            height: 650px;
            width: 50%;
            text-decoration-color: darkred;
            float: left;
            padding-top: 100px;
        }
    
    #div2{
        float:right;
        height: 500px;
        width: 48%;
        padding-top: 100px;
    }
        #div0{
            height: 50px;
            width: 100%;
            background-color: blue;
            position: fixed;
            margin: 0px;
            
        } 
		#footer{
            height: 50px;
            width: 100%;
            background-color: grey;
            position: relative;
            margin: 0px;
            
        } 
       
    *, html, body{
    margin: 0;
    padding: 0;
}


ul
{
    list-style: none;
   
}
ul li{
display: inline-block;
    float: right;
    padding-top: 15px;
    
}
        nav ul li a{
    padding-right: 50px;
    font-weight: bold;
    color: white;
     text-decoration: none;
    transition: 0.8s ease-in;
}
        a:hover{
            color: aqua;
            font-size: 25px;
        } 
        #h33{
            float: right;
            padding-top: 15px;
        }
		.clear{

		clear: both;
		}
    
    </style>
    
    
</head>
<body>
     <div id="div0">
     
      <nav>
      <h1 style="float:left; color:white; padding-top:15px; padding-left:15px">welcome to BLAB travel and tour</h1>
      <ul>
      <li></li> 
       <li><a href="admin/index.php">Admin Log In</a></li>
       <li><a href="signup.php">Sign Up</a></li>
       <li><a href="contact.php">Contact Us</a></li>
       <li><a href="booking.php">book a ticket</a></li>
       </ul>
       </nav>
     </div>
     
     
     
     
      <div id="div1">
      <div>
      	<?php if (isset($_SESSION['success'])): ?>
      	<h3>
      		<?php 
				echo $_SESSION['success'];
				unset($_SESSION['success']);
			?>
      	</h3>
      	<?php endif; ?>
      </div>
    
    <?php if (isset($_SESSION['username'])): ?>
		  <p>welcome: <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p><a href="buslog-in.php?logout='1'" style="color:red; text-decoration: none; font-size:20px;">logout</a></p>
    <?php endif; ?>
    <h2 style="color: white; font-display: fallback">CHECKOUT OUR ROUTES AND FARES FROM THE DROP DOWN</h2>
           <hr>
            <h1> routes from Accra</h1>
     <p>
      
        <select>
            <option>Accra-to-kumasi (ghs 50.00)</option>
            <option>Accra-to-capecoast (ghs 70.00)</option>
            <option>Accra-to-ho (ghs 60.00)</option>
            <option>Accra-to-Tamale (ghs 80.00)</option>
        </select>
        </p>
        
                <h1>routes from Tamale</h1>

     <p>
       
        <select>
            <option>Tamale-to-Accra (ghs 120.00)</option>
            <option>Tamale-to-Kumasi (ghs 120.00)</option>
            <option>Tamale-to-Capecoast (ghs 110.00)</option>
            <option>Tamale-to-Ho (ghs 100.00)</option>
        </select>
        </p>
        
                <h1>routes from kumasi </h1>

     <p>
        <select>
            <option>Kumasi-To-Accra (ghs 50.00)</option>
            <option>Kumasi-To-tamale (ghs 120.00)</option>
            <option>Kumasi-To-Capecoast (ghs 30.00)</option>
            <option>Kumasi-To-Ho (ghs 40.00)</option>
        </select>
        </p>
     <hr>
    
   </div> 
   
        
        
        <div id="div2">
          <img src="images/images.png" alt="">  
        <img src="images/download%20(4).jpg" alt="">  
        <img src="images/download%20(6).jpg" alt="">  
          <img src="images/images.png" alt="">  
        <img src="images/download%20(8).jpg" alt="">  
        <img src="images/download%20(9).jpg" alt="">
        <h2 style="font-style: italic">the luxury of traveling</h2> 
         
        </div>
        <div class="clear"></div>
        
     <div id="footer">
      <nav>
      <h1 style="float:left; color:white; padding-top:15px; padding-left:15px">welcome to BLAB travel and tour</h1>
      <ul>
      <li></li> 
       <li><a href="twitter.com/eddiebrempong"><img src="" alt=""></a></li>
       <li><a href="">@eddiebrempong</a></li>
       <li><a href="contact.php">Contact Us</a></li>
       </ul>
       </nav>
      
     </div>
</body>
</html>